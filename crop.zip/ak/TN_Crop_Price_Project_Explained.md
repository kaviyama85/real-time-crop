# 🌾 TN Crop Price Analysis — Complete Project Guide
### Everything explained from scratch, for a complete beginner

---

## 📌 Table of Contents

1. [What is this project?](#1-what-is-this-project)
2. [What problem does it solve?](#2-what-problem-does-it-solve)
3. [The Big Picture — How it all works together](#3-the-big-picture)
4. [What is an API? (explained simply)](#4-what-is-an-api-explained-simply)
5. [The Real-Time Data Source — data.gov.in Agmarknet API](#5-the-real-time-data-source)
6. [Is the data actually real-time?](#6-is-the-data-actually-real-time)
7. [Project Structure — Every file explained](#7-project-structure)
8. [The Backend — What it does and how](#8-the-backend)
9. [The Frontend — What the user sees](#9-the-frontend)
10. [Complete Data Flow — Step by step](#10-complete-data-flow)
11. [Fallback System — What happens when API fails](#11-fallback-system)
12. [Caching — Why and how](#12-caching)
13. [Price Conversion — Quintals to Kilograms](#13-price-conversion)
14. [All the Files — Plain English](#14-all-the-files-plain-english)
15. [Technology Stack Summary](#15-technology-stack-summary)
16. [Common Beginner Questions Answered](#16-common-beginner-questions)

---

## 1. What is this project?

This is a **web application** that shows crop prices in Tamil Nadu.

Think of it like a price-checking app but for farmers and agricultural traders. You open the app in your browser, select a district (like Chennai or Coimbatore) and a crop (like Tomato or Onion), and it shows you:

- The **current price** per kg in your district
- Prices across **different market yards (mandis)**
- How prices have changed over the **past week or month** (chart)
- A **comparison across all 38 Tamil Nadu districts**

---

## 2. What problem does it solve?

Farmers in Tamil Nadu often don't know what price their crop is fetching in different districts. A tomato farmer in Dindigul might sell at ₹20/kg locally, not knowing it's ₹35/kg in Chennai. This app solves that by:

- Pulling **live market data** from the government's Agmarknet system
- Showing district-wise price comparisons on a map/chart
- Giving price trends so farmers can decide the best time to sell

---

## 3. The Big Picture

Here is the entire project in one picture:

```
┌─────────────────────────────────────────────────────────────┐
│                        YOUR BROWSER                         │
│                    (frontend/index.html)                    │
│   User selects: District = Chennai, Crop = Tomato          │
│   Clicks "View Prices"                                      │
└───────────────────────┬─────────────────────────────────────┘
                        │  HTTP Request
                        │  GET /api/prices/live?crop=tomato&district=Chennai
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                     YOUR COMPUTER                           │
│                  (backend/server.js)                        │
│   Node.js + Express server running on port 3001            │
│   Receives the request, checks cache first                 │
└───────────────────────┬─────────────────────────────────────┘
                        │  HTTP Request (if not cached)
                        │  GET https://api.data.gov.in/resource/...
                        ▼
┌─────────────────────────────────────────────────────────────┐
│               GOVERNMENT SERVER (data.gov.in)               │
│                  Agmarknet API                             │
│   Returns crop price records from Tamil Nadu mandis        │
└───────────────────────┬─────────────────────────────────────┘
                        │  JSON Response (price data)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                     YOUR COMPUTER                           │
│              (backend processes the data)                   │
│   - Filters for Tamil Nadu records                         │
│   - Converts ₹/Quintal → ₹/kg                              │
│   - Stores in cache for 5 minutes                          │
│   - Sends clean response to browser                        │
└───────────────────────┬─────────────────────────────────────┘
                        │  JSON Response (clean, ready to display)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                        YOUR BROWSER                         │
│   Displays: ₹35/kg, chart, mandi list, district map       │
└─────────────────────────────────────────────────────────────┘
```

**In simple words:**
> Browser → Your Backend → Government API → Your Backend → Browser

---

## 4. What is an API? (Explained Simply)

An **API (Application Programming Interface)** is like a waiter at a restaurant.

- You (your app) are the customer
- The government's database is the kitchen
- The API is the waiter who takes your order and brings back food

You don't need to go into the kitchen yourself. You just tell the waiter: *"I want tomato prices from Tamil Nadu"* — and the waiter (API) brings it back to you in a standard format (JSON).

**JSON** is just a way of writing data that computers understand:
```json
{
  "crop": "Tomato",
  "price": "3500",
  "district": "Chennai",
  "date": "01/04/2026"
}
```

---

## 5. The Real-Time Data Source

**API used:** `https://api.data.gov.in`

**Specific dataset:** Agmarknet — Agricultural Marketing Information Network

**Resource ID:** `9ef84268-d588-465a-a308-a864a43d0070`

### What is Agmarknet?

Agmarknet is a **national database** maintained by the Indian government that collects daily market prices from thousands of mandis (agricultural market yards) across India. These prices are reported by mandi officials every day.

### What data does the API return?

Each record from the API looks like this (simplified):

```json
{
  "state": "Tamil Nadu",
  "district": "Chennai",
  "market": "Koyambedu",
  "commodity": "Tomato",
  "min_price": "2000",
  "max_price": "4500",
  "modal_price": "3500",
  "arrival_date": "01/04/2026"
}
```

**Important terms:**
- `min_price` — Lowest price recorded that day
- `max_price` — Highest price recorded that day
- `modal_price` — The **most common/representative** price (like the average)
- All prices are in **₹ per Quintal** (100 kg)

### How does the app query the API?

The app sends a request like:
```
GET https://api.data.gov.in/resource/9ef84268-.../
  ?api-key=YOUR_KEY
  &format=json
  &filters[state]=Tamil Nadu
  &filters[commodity]=Tomato
  &limit=300
```

---

## 6. Is the Data Actually Real-Time?

**Partially yes, partially no.** Here is the honest breakdown:

| Aspect | Reality |
|--------|---------|
| **Data freshness** | Updated once daily by mandi officials |
| **Not streaming live** | It is NOT second-by-second live like stock prices |
| **Government dependent** | Data is only as fresh as what mandis report |
| **Some mandis missing** | Not every district's mandi reports every day |
| **API lag** | Can be 1-2 days behind actual market prices |

### What happens when no live data is found?

The app has a **fallback system** (explained in Section 11) that uses pre-built estimated prices based on historical patterns. It is realistic and clearly labeled so the user knows it's an estimate.

**Green badge** = Live data from Agmarknet  
**Yellow badge** = Estimated/fallback data  

---

## 7. Project Structure

```
tn-crop-price/
│
├── backend/                    ← The server (runs on your computer)
│   ├── server.js               ← Main entry point, starts everything
│   ├── package.json            ← List of dependencies (npm packages)
│   ├── .env                    ← Secret config (API key, port number)
│   │
│   ├── routes/                 ← URL handlers
│   │   ├── prices.js           ← Handles /api/prices/... requests
│   │   ├── history.js          ← Handles /api/history/... requests
│   │   └── health.js           ← Handles /api/health (is server alive?)
│   │
│   ├── services/               ← Business logic (the actual work)
│   │   ├── agmarknet.js        ← Talks to data.gov.in API
│   │   └── history.js          ← Generates price history charts
│   │
│   └── utils/                  ← Shared tools
│       ├── constants.js        ← All districts, crops, default prices
│       └── cache.js            ← Memory storage to avoid repeat API calls
│
└── frontend/
    └── index.html              ← The entire UI (one HTML file)
```

---

## 8. The Backend

The backend is a **Node.js + Express** server. Think of it as a middleman between your browser and the government's API.

### Why do we need a backend at all?

Can't the browser just call the government API directly? **No, for two reasons:**

1. **CORS Security** — Browsers block direct calls to external APIs from web pages (security rule). The backend bypasses this.
2. **API Key Safety** — You don't want to expose your secret API key in the browser (anyone could steal it). The backend keeps it hidden.

### What does server.js do?

```
server.js starts up and:
1. Loads your API key from .env file
2. Sets up security (helmet, rate limiting)
3. Sets up CORS (allows your browser to talk to backend)
4. Registers routes (which URLs do what)
5. Starts listening on port 3001
```

### The Three Routes

**Route 1: `/api/health`**
```
Browser asks: "Are you alive?"
Server replies: { "status": "ok" }
```

**Route 2: `/api/prices/live?crop=tomato&district=Chennai`**
```
Browser asks: "What's the tomato price in Chennai?"
Backend:
  1. Checks cache (was this asked in last 5 min?)
  2. If cached → return stored answer
  3. If not → call data.gov.in API
  4. Process response → return to browser
```

**Route 3: `/api/prices/districts?crop=tomato`**
```
Browser asks: "What's the tomato price in ALL 38 districts?"
Backend: Fetches data and returns a map of {district: price}
```

**Route 4: `/api/history/week?crop=tomato&priceKg=35`**
```
Browser asks: "What were tomato prices for the past 7 days?"
Backend: Generates realistic historical chart data
```

---

## 9. The Frontend

The entire user interface is a **single HTML file** (`index.html`). It uses:

- **HTML** — Structure (buttons, dropdowns, cards)
- **CSS** — Styling (colors, layout, fonts)
- **JavaScript** — Logic (fetch data, update charts, handle clicks)
- **Chart.js** — Library for drawing price trend charts
- **Leaflet.js** — Library for the district map

### What the user sees step by step:

```
Step 1: Landing page with "Get Started" button

Step 2: Select your district from dropdown (38 options)

Step 3: Select your crop (12 options: Tomato, Rice, Onion, etc.)

Step 4: Click "View Prices"

Step 5: App shows:
  ├── Current price card (₹/kg, min, max)
  ├── Price trend chart (last 7 days or 30 days)
  ├── Mandi-wise breakdown (5 market yards)
  └── District comparison map (all 38 districts)
```

---

## 10. Complete Data Flow

Here is exactly what happens when you click "View Prices":

```
STEP 1: Browser sends request
  GET http://localhost:3001/api/prices/live?crop=tomato&district=Chennai

STEP 2: server.js receives it, passes to prices.js route

STEP 3: prices.js checks cache
  → If cached (within 5 min): return stored data immediately
  → If not cached: continue to Step 4

STEP 4: prices.js calls agmarknet.js → getLivePrice("tomato", "Chennai")

STEP 5: agmarknet.js builds API request
  Crop "tomato" has aliases: ["tomato"]
  So it calls: data.gov.in?state=Tamil Nadu&commodity=tomato

STEP 6: data.gov.in returns JSON with records
  Each record has: district, market, min_price, modal_price, max_price, date

STEP 7: agmarknet.js filters records
  → Keep only Tamil Nadu records
  → Find records for "Chennai"
  → If no Chennai records, use all TN records (still better than nothing)

STEP 8: agmarknet.js processes prices
  → Converts ₹/Quintal to ₹/kg (divide by 100)
  → Calculates average modal price
  → Builds mandi list

STEP 9: Result is cached for 5 minutes

STEP 10: Response sent to browser
  {
    "priceKg": 35.50,
    "minKg": 25.00,
    "maxKg": 52.00,
    "mandis": [...5 mandis with individual prices...],
    "asOf": "2026-04-01",
    "source": "live",
    "cached": false
  }

STEP 11: Browser displays price cards, chart is fetched separately
```

---

## 11. Fallback System

When the government API returns no data (which happens often for less-reported districts/crops), the app doesn't crash. It uses built-in fallback estimates.

### How fallback prices are calculated:

**Base prices** (in `constants.js`):
```
Tomato: ₹35/kg (average)
Onion:  ₹28/kg (average)
Rice:   ₹22/kg (average)
...
```

**District multipliers** (also in `constants.js`):
```
Chennai tomato multiplier: 1.20 → ₹35 × 1.20 = ₹42/kg
Dindigul tomato multiplier: 0.85 → ₹35 × 0.85 = ₹29.75/kg
Nilgiris tomato multiplier: 0.80 → ₹35 × 0.80 = ₹28/kg
```

This reflects real-world patterns — Chennai prices are higher due to demand, interior districts are lower.

**Mandi variation** within a district uses a seeded random function:
```
A seeded random means: same input → same output (always)
So prices don't change on every refresh — they stay stable
```

---

## 12. Caching

Caching is like remembering an answer so you don't have to look it up again.

### Why cache?

- data.gov.in has rate limits — you can't hammer it with 100 requests/min
- API calls take 1-3 seconds — cached responses are instant
- The prices don't change every second, so serving a 5-minute-old price is fine

### Three separate caches:

| Cache | What it stores | How long |
|-------|---------------|----------|
| `liveCache` | Current price for crop+district | 5 minutes |
| `distCache` | All district prices for one crop | 10 minutes |
| `historyCache` | Weekly/monthly chart data | 1 hour |

### How caching works:

```
Request: tomato + Chennai

1. Check liveCache for key "live:tomato:Chennai"
2. Found? → Return stored data immediately (no API call)
3. Not found? → Call API, store result, return it
4. Next request within 5 min → Cached response
5. After 5 min → Cache expired, next request calls API again
```

---

## 13. Price Conversion

The Agmarknet API always returns prices in **₹ per Quintal**.

**1 Quintal = 100 kg**

So the conversion is simple:
```
₹/Quintal ÷ 100 = ₹/kg

Example: Modal price = ₹3500/Quintal
₹3500 ÷ 100 = ₹35/kg
```

This is done in `agmarknet.js`:
```javascript
function quintalToKg(val) {
  const n = parseFloat(val);
  return +(n / 100).toFixed(2);  // 2 decimal places
}
```

---

## 14. All the Files — Plain English

### `server.js` — The Boss
Starts everything. Sets up security, registers all routes, begins listening for requests on port 3001. This is the first file that runs when you type `node server.js`.

### `routes/prices.js` — Price Request Handler
When your browser asks for a price, this file handles it. It checks the cache, calls agmarknet.js if needed, and sends back the answer.

### `routes/history.js` — History Request Handler
When your browser asks for chart data (past 7 or 30 days), this file handles it. It calls the history service and caches the result.

### `routes/health.js` — Health Check
A tiny file with one job: when someone visits `/api/health`, say `{"status":"ok"}`. Used to test if the backend is running.

### `services/agmarknet.js` — The Real Worker
This is the most important file. It:
- Talks to data.gov.in API
- Handles field name inconsistencies (API uses different names sometimes)
- Filters Tamil Nadu records
- Converts prices
- Builds the mandi list
- Falls back to estimates when needed

### `services/history.js` — Chart Data Generator
Generates realistic price history for the last 7 or 30 days. Uses a mathematical formula anchored to today's real price, so the chart always ends at the current price.

### `utils/constants.js` — The Database
Contains all the static data:
- 12 crop names and aliases (to match API naming)
- Base prices for all 12 crops
- Price multipliers for all 38 districts × 12 crops = 456 values
- List of top 5 mandis for each of the 38 districts
- All 38 district names

### `utils/cache.js` — Memory Storage
Creates three in-memory stores using `node-cache`. Data lives here temporarily between API calls.

### `.env` — Secret Configuration
A text file that stores your API key and settings. Never shared or uploaded. Looks like:
```
DATA_GOV_API_KEY=your_secret_key_here
PORT=3001
NODE_ENV=development
FRONTEND_ORIGIN=http://localhost:5500
```

### `package.json` — Dependency List
Lists all the npm packages this project needs. When you run `npm install`, npm reads this file and downloads everything.

### `frontend/index.html` — The Entire UI
One big HTML file that is the whole user interface. Contains HTML structure, CSS styling, and JavaScript logic all in one place.

---

## 15. Technology Stack Summary

| Technology | What it is | Why used here |
|------------|-----------|---------------|
| **Node.js** | JavaScript runtime (runs JS outside browser) | Powers the backend server |
| **Express** | Web framework for Node.js | Makes it easy to create routes and handle requests |
| **axios** | HTTP client library | Makes API calls to data.gov.in |
| **cors** | Middleware | Allows browser to talk to backend |
| **helmet** | Security middleware | Adds HTTP security headers |
| **morgan** | Logging middleware | Prints request logs to terminal |
| **express-rate-limit** | Rate limiting | Prevents too many requests per minute |
| **node-cache** | In-memory cache | Stores API responses temporarily |
| **dotenv** | Environment variable loader | Reads .env file |
| **Chart.js** | Frontend chart library | Draws price trend line charts |
| **Leaflet.js** | Frontend map library | Shows district comparison map |
| **data.gov.in API** | Government API | Provides real Agmarknet price data |

---

## 16. Common Beginner Questions

**Q: Why do we need two separate servers (backend + Live Server)?**
> The backend (port 3001) is the API server — it has your secret API key and calls data.gov.in. The Live Server (port 5500) just serves your HTML file. They're separate jobs.

**Q: What is port 3001?**
> Think of ports like apartment numbers in a building. Your computer is the building. Port 3001 is the apartment where the backend lives. Port 5500 is where your HTML file lives. Requests go to the right apartment.

**Q: Does this app store any data permanently?**
> No. The cache is in-memory (RAM). When you stop the server, all cached data disappears. There is no database.

**Q: What happens if I don't have an API key?**
> The backend starts but all API calls fail with "API key not set". It still works — it just always returns fallback (estimated) prices.

**Q: How accurate are the fallback prices?**
> They are realistic estimates based on historical patterns, but they are NOT live data. They're labeled clearly so users know.

**Q: Why does the API sometimes return 0 records?**
> Some crops/districts are not well-reported in Agmarknet. Rural districts report less frequently. The app handles this gracefully with fallback.

**Q: What is a "seeded random" in history.js?**
> A normal random number changes every time. A seeded random uses a formula: `Math.sin(seed) * 10000` — same seed always gives same number. This is used so the price chart looks realistic but doesn't flicker/change on every page refresh.

**Q: What does CORS mean?**
> Cross-Origin Resource Sharing. A browser security rule that blocks a webpage from calling APIs on a different domain. Since your HTML is on port 5500 and your API is on port 3001, they're considered different "origins". The backend's CORS settings explicitly allow port 5500.

---

## Summary in One Paragraph

This is a **full-stack web application** that fetches crop price data for Tamil Nadu from the Indian government's **Agmarknet API** (data.gov.in), processes it, and displays it in a browser UI. It has two parts: a **Node.js/Express backend** (runs on your computer, port 3001) that acts as a secure proxy to the government API, and a **frontend HTML page** (port 5500) that shows prices, charts, and district maps. The backend fetches live prices, converts them from ₹/Quintal to ₹/kg, caches results for 5 minutes, and falls back to pre-built estimated prices when the government API has no data. The data from Agmarknet is updated once daily by mandi officials, so it is near-real-time but not second-by-second live.

---

*Generated for TN Crop Price Analysis Project | April 2026*
