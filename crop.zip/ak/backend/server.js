// ════════════════════════════════════════════════════════════════════════════
// Tamil Nadu Crop Price Analysis – Backend Server
// Node.js + Express | Proxy for data.gov.in Agmarknet API
// ════════════════════════════════════════════════════════════════════════════
require('dotenv').config();

const express  = require('express');
const cors     = require('cors');
const helmet   = require('helmet');
const morgan   = require('morgan');
const rateLimit = require('express-rate-limit');

const priceRoutes   = require('./routes/prices');
const historyRoutes = require('./routes/history');
const healthRoute   = require('./routes/health');

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Security & Middleware ────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
app.use(express.json());

// CORS – allow frontend origin
app.use(cors({
  origin: [
    process.env.FRONTEND_ORIGIN || 'http://localhost:3000',
    'http://127.0.0.1:3000',
    'http://localhost:5500',  // VS Code Live Server
    'http://127.0.0.1:5500',
    'null',                   // file:// protocol (open HTML directly)
  ],
  methods: ['GET'],
  credentials: false,
}));

// Rate limiting – protect backend and be kind to data.gov.in
const apiLimiter = rateLimit({
  windowMs : 60 * 1000,  // 1 minute window
  max      : 60,         // 60 requests/min per IP
  standardHeaders: true,
  legacyHeaders  : false,
  message: { error: 'Too many requests, please wait a moment.' },
});
app.use('/api/', apiLimiter);

// ── Routes ───────────────────────────────────────────────────────────────────
app.use('/api/health',  healthRoute);
app.use('/api/prices',  priceRoutes);
app.use('/api/history', historyRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found', path: req.path });
});

// Global error handler
app.use((err, req, res, _next) => {
  console.error('[ERROR]', err.message);
  res.status(500).json({ error: 'Internal server error', message: err.message });
});

// ── Start ────────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🌾 TN Crop Price Backend running on http://localhost:${PORT}`);
  console.log(`   API key configured: ${process.env.DATA_GOV_API_KEY ? '✅' : '❌ (set DATA_GOV_API_KEY in .env)'}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}\n`);
});