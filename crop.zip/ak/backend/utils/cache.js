// ── Cache Utility ────────────────────────────────────────────────────────────
// Shared in-memory cache using node-cache
// Prevents hammering data.gov.in API on every frontend request

const NodeCache = require('node-cache');

// Separate caches with different TTLs
const liveCache    = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL_LIVE    || 300)  });
const historyCache = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL_HISTORY || 3600) });
const distCache    = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL_DISTRICT|| 600)  });

module.exports = { liveCache, historyCache, distCache };