


## 📋 README — Step by Step

═══════════════════════════════════════════════
  TN Crop Price Analysis — Setup Guide
═══════════════════════════════════════════════

PREREQUISITES
─────────────
- Node.js v18 or higher  →  https://nodejs.org
- A free API key from    →  https://data.gov.in

─────────────────────────────────────────────
STEP 1 — Set up the folder
─────────────────────────────────────────────
Create this structure:

  tn-crop-price/
  ├── backend/
  │   ├── server.js
  │   ├── package.json
  │   ├── .env
  │   ├── routes/
  │   │   ├── prices.js
  │   │   ├── history.js
  │   │   └── health.js
  │   ├── services/
  │   │   └── agmarknet.js
  │   └── utils/
  │       ├── constants.js
  │       └── cache.js
  └── frontend/
      └── index.html

─────────────────────────────────────────────
STEP 2 — Create the .env file
─────────────────────────────────────────────
Inside the backend/ folder, create a file
named exactly:  .env

Paste this inside it:

  DATA_GOV_API_KEY=your_key_here
  PORT=3001
  NODE_ENV=development
  FRONTEND_ORIGIN=http://localhost:5500

Replace "your_key_here" with your data.gov.in
API key.

─────────────────────────────────────────────
STEP 3 — Create the missing health.js file
─────────────────────────────────────────────
Create  backend/routes/health.js  with:

  const express = require('express');
  const router = express.Router();
  router.get('/', (req, res) => res.json({ status: 'ok' }));
  module.exports = router;

─────────────────────────────────────────────
STEP 4 — Install backend dependencies
─────────────────────────────────────────────
Open your terminal, go into the backend folder:

  cd tn-crop-price/backend
  npm install

This installs: express, axios, cors, helmet,
node-cache, morgan, express-rate-limit, dotenv

─────────────────────────────────────────────
STEP 5 — Start the backend server
─────────────────────────────────────────────
Still inside backend/:

  node server.js

You should see:
  🌾 TN Crop Price Backend running on http://localhost:3001
  API key configured: ✅

Leave this terminal running. Do NOT close it.

─────────────────────────────────────────────
STEP 6 — Open the frontend
─────────────────────────────────────────────
Option A (Recommended — VS Code):
  Install the "Live Server" extension in VS Code
  Right-click frontend/index.html → "Open with Live Server"
  It opens at: http://127.0.0.1:5500

Option B (Direct file):
  Just double-click frontend/index.html
  Note: the backend CORS config already allows file:// 
  so this will work, but Live Server is cleaner.

─────────────────────────────────────────────
STEP 7 — Verify everything works
─────────────────────────────────────────────
1. Open your browser to the frontend URL
2. Click "Get Started"
3. Select any district (e.g. Chennai)
4. Select any crop (e.g. Tomato)
5. Click "View Prices"

- Green badge = live Agmarknet data loaded ✅
- Yellow badge = API returned no data, showing
  estimated fallback prices (still works fine)
- Red toast = backend not running, check Step 5

─────────────────────────────────────────────
QUICK TEST — Check backend is alive
─────────────────────────────────────────────
Open this URL in your browser:

  http://localhost:3001/api/health

You should see:  {"status":"ok"}

─────────────────────────────────────────────
TROUBLESHOOTING
─────────────────────────────────────────────
❌ "Cannot find module" error
   → Make sure you ran: npm install (Step 4)

❌ "API key configured: ❌"
   → Check your .env file is inside backend/
     and has the correct key (no quotes needed)

❌ Prices show red "Backend not reachable" toast
   → Make sure Step 5 terminal is still running
   → Make sure you're on port 3001

❌ CORS error in browser console
   → Use Live Server (port 5500) or
     update FRONTEND_ORIGIN in .env

─────────────────────────────────────────────
HOW DATA WORKS
─────────────────────────────────────────────
- Frontend calls backend at localhost:3001
- Backend calls data.gov.in Agmarknet API
- Prices come in ₹/Quintal → converted to ₹/kg
- If live API has no data for a crop/district,
  the system uses built-in fallback estimates
- All API calls are cached (5 min for live
  prices, 10 min for district comparison,
  1 hour for price history charts)

═══════════════════════════════════════════════