// ════════════════════════════════════════════════════════════════════════════
// Price History Service
// Generates realistic weekly/monthly price history for a crop+district.
// Uses seeded determinism so charts don't flicker on refresh.
// ════════════════════════════════════════════════════════════════════════════

function seededRand(seed) {
  const x = Math.sin(seed + 1) * 10000;
  return x - Math.floor(x);
}

/**
 * Generate daily price data anchored to a known current price.
 * @param {number} currentPriceKg  - The actual price right now (from live API or fallback)
 * @param {string} cropId
 * @param {number} daysBack        - How many days of history to generate
 * @returns {{ labels: string[], prices: number[] }}
 */
function generateHistory(currentPriceKg, cropId, daysBack = 30) {
  const today  = new Date();
  const labels = [];
  const prices = [];
  const cropSeed = cropId.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);

  // Work backwards from today, so price[last] ≈ currentPriceKg
  const rawPrices = [];
  for (let d = daysBack; d >= 0; d--) {
    const seed  = d * 37 + cropSeed * 13;
    const trend = Math.sin(d / 14) * 0.06;
    const noise = (seededRand(seed) - 0.5) * 0.10;
    rawPrices.push(1 + trend + noise);
  }

  // Scale so that last entry = currentPriceKg
  const lastFactor = rawPrices[rawPrices.length - 1];
  const scaledPrices = rawPrices.map(f => +(currentPriceKg * (f / lastFactor)).toFixed(2));

  for (let d = daysBack; d >= 0; d--) {
    const date = new Date(today);
    date.setDate(today.getDate() - d);
    labels.push(date.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }));
    prices.push(scaledPrices[daysBack - d]);
  }

  return { labels, prices };
}

/**
 * Weekly history: last 7 days
 */
function getWeekHistory(currentPriceKg, cropId) {
  return generateHistory(currentPriceKg, cropId, 7);
}

/**
 * Monthly history: all days in a specific month
 */
function getMonthHistory(currentPriceKg, cropId, year, month) {
  const today      = new Date();
  const isCurrentM = (year === today.getFullYear() && month === today.getMonth());
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysToShow  = isCurrentM ? today.getDate() : daysInMonth;
  return generateHistory(currentPriceKg, cropId, daysToShow);
}

module.exports = { getWeekHistory, getMonthHistory };
