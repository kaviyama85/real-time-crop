// ════════════════════════════════════════════════════════════════════════════
// /api/prices  –  Live & District Price Routes
// ════════════════════════════════════════════════════════════════════════════
const express     = require('express');
const router      = express.Router();
const { getLivePrice, getDistrictComparison } = require('../services/agmarknet');
const { liveCache, distCache }  = require('../utils/cache')
const { CROP_DEFAULTS, ALL_DISTRICTS } = require('../utils/constants');

// ── GET /api/prices/live?crop=tomato&district=Chennai ──────────8───────────────
router.get('/live', async (req, res) => {
  const { crop, district } = req.query;

  if (!crop || !district) {
    return res.status(400).json({ error: 'crop and district query params are required' });
  }
  if (!CROP_DEFAULTS[crop]) {
    return res.status(400).json({ error: `Unknown crop: ${crop}` });
  }

  const cacheKey = `live:${crop}:${district}`;
  const cached   = liveCache.get(cacheKey);
  if (cached) {
    return res.json({ ...cached, cached: true });
  }

  try {
    const data = await getLivePrice(crop, district);
    liveCache.set(cacheKey, data);
    res.json({ ...data, cached: false });
  } catch (err) {
    console.error('[prices/live]', err.message);
    // Always return a valid fallback – never crash the frontend
    const { buildFallback } = require('../../services/agmarknet');
    const { CROP_DEFAULTS } = require('../constants');
    const fb = buildFallback(crop, district, CROP_DEFAULTS[crop]);
    res.json({ ...fb, cached: false, error: 'API unavailable, showing model data' });
  }
});

// ── GET /api/prices/districts?crop=tomato ────────────────────────────────────
router.get('/districts', async (req, res) => {
  const { crop } = req.query;

  if (!crop || !CROP_DEFAULTS[crop]) {
    return res.status(400).json({ error: 'Valid crop query param required' });
  }

  const cacheKey = `dist:${crop}`;
  const cached   = distCache.get(cacheKey);
  if (cached) {
    return res.json({ prices: cached, cached: true });
  }

  try {
    const prices = await getDistrictComparison(crop);
    distCache.set(cacheKey, prices);
    res.json({ prices, cached: false });
  } catch (err) {
    console.error('[prices/districts]', err.message);
    // Pure fallback from constants
    const { CROP_DEFAULTS, DISTRICT_PRICE_FACTORS } = require('../constants');
    const base   = CROP_DEFAULTS[crop].priceKg;
    const prices = {};
    ALL_DISTRICTS.forEach(d => {
      prices[d] = +( base * ((DISTRICT_PRICE_FACTORS[d] || {})[crop] || 1.0) ).toFixed(2);
    });
    res.json({ prices, cached: false, source: 'fallback' });
  }
});

module.exports = router;