
// ════════════════════════════════════════════════════════════════════════════
// /api/history  –  Price History Routes
// ════════════════════════════════════════════════════════════════════════════
const express   = require('express');
const router    = express.Router();
const { getWeekHistory, getMonthHistory } = require('../services/history');
const { historyCache } = require('../utils/cache');
const { CROP_DEFAULTS } = require('../utils/constants');

// ── GET /api/history/week?crop=tomato&priceKg=35 ─────────────────────────────
router.get('/week', (req, res) => {
  const { crop, priceKg } = req.query;
  if (!crop) return res.status(400).json({ error: 'crop param required' });

  const basePrice = parseFloat(priceKg) || (CROP_DEFAULTS[crop] || {}).priceKg || 20;
  const cacheKey  = `week:${crop}:${Math.round(basePrice)}`;
  const cached    = historyCache.get(cacheKey);
  if (cached) return res.json({ ...cached, cached: true });

  const data = getWeekHistory(basePrice, crop);
  historyCache.set(cacheKey, data);
  res.json({ ...data, cached: false });
});

// ── GET /api/history/month?crop=tomato&priceKg=35&year=2025&month=2 ──────────
router.get('/month', (req, res) => {
  const { crop, priceKg, year, month } = req.query;
  if (!crop || !year || month === undefined) {
    return res.status(400).json({ error: 'crop, year, month params required' });
  }

  const basePrice = parseFloat(priceKg) || (CROP_DEFAULTS[crop] || {}).priceKg || 20;
  const y  = parseInt(year);
  const m  = parseInt(month);
  const ck = `month:${crop}:${Math.round(basePrice)}:${y}:${m}`;
  const cached = historyCache.get(ck);
  if (cached) return res.json({ ...cached, cached: true });

  const data = getMonthHistory(basePrice, crop, y, m);
  historyCache.set(ck, data);
  res.json({ ...data, cached: false });
});

module.exports = router;